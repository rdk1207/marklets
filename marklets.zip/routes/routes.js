var express = require('express');
var router = express.Router();

/**
 * Database Stuff
 */

var mongo = require('mongodb');
var MongoClient = mongo.MongoClient;
var assert = require('assert');
var dburl = 'mongodb://localhost:27017/markletsdb';
var documentsCollection = null;

MongoClient.connect(dburl, function(err, db) {
  assert.equal(null, err);
  console.log("Connected correctly to server");
  documentsCollection = db.collection('documents');
});


/** GET ENDPOINTS */

router.get('/add', function(req, res, next) {
  res.render('add', { title: 'Express' });
});

router.get('/page/:uid', function(req, res, next) {
  
  var oid = new mongo.ObjectID(req.params.uid); //convert uid into mongo object id
  
  
  
  documentsCollection.find({'_id': oid}).limit(1).toArray(function(err, docs) {
    assert.equal(null, err);
    if(docs.length === 1) res.render('page', {title: req.params.uid, markdown: docs[0].markdown});
    else res.render('error', {message: req.params.uid + ' not found', error: {}});
  });
});


/** POST ENDPOINTS */

router.post('/addpage', function(req, res, next){
  
  assert.equal(typeof req.body.markdown, 'string');
  assert.equal(typeof req.body.passphrase, 'string');
  
  documentsCollection.insertOne({
    markdown: req.body.markdown,
    passphrase: req.body.passphrase
  }, function(err, result){
    assert.equal(err, null);
    console.log('successfully saved page to db');
    res.send('success! ' + result.insertedId);
  });
});


module.exports = router;
